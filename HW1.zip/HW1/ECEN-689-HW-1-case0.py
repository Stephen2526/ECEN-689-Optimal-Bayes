#!/usr/bin/python
import numpy as np
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt

## fixed true distribution c=0.5, p,q-Zipf power law

alphaArr = np.append([np.arange(3, 2, -0.1)], [np.arange(2, 1, -0.1)])
alphaArr = np.append(alphaArr, [np.arange(1, 0, -0.05)])
alphaArr = np.append(alphaArr, [np.arange(0.04, 0, -0.01)])
alphaArr = np.insert(alphaArr, 0, 100)
#print("alphaArr: ", alphaArr)
c = 0.5
b = 16
N = 20
spNum = 100000
iArray = np.arange(1,17)
bayesErr = np.empty([0])
RMS_LOO_ARR = np.empty([0])
RMS_RESUB_ARR = np.empty([0])
RMS_BMMSE_ARR = np.empty([0])
## prior: c=0.5, p,q-Dirichlet
alphaC0 = np.array([[2]*8+[1]*8,[4]*8+[1]*8,[8]*8+[1]*8])
alphaC1 = np.array([[1]*8+[2]*8,[1]*8+[4]*8,[1]*8+[8]*8])
caseNum = 0

## loop on alpha
for alpha in alphaArr:
    print("alpha: ", alpha)
    ### generate CCD class 0:p_i, class 1:q_i from zipf distri
    if alpha == 100:
        # special case when BE = 0
        p_i = np.append([1], [0]*15)
        q_i = np.flip(p_i, 0)
    else:
        iMinusA = np.power(iArray, -1*alpha)
        sumIMinusA = np.sum(iMinusA)
        p_i = iMinusA/sumIMinusA
        q_i = np.flip(p_i,0)
    print("p: ", p_i)
    
    ### generate Bayes Error
    errArr = np.array([p_i*c, q_i*(1-c)])
    binWiseMinErr = np.amin(errArr, axis=0)
    #print(errArr, "///", binWiseMinErr)
    BE = np.sum(binWiseMinErr)
    print("BE: ", BE)
    bayesErr = np.append(bayesErr, BE)
    
    RMS_LOO = 0.
    RMS_RESUB = 0.
    RMS_BMMSE = 0.
    #TODO: loop on samples
    for tmpT in np.arange(spNum):
        ## Step A: generate sample ## 
        ###class size no, n1 with binomial expe
        n0 = np.random.binomial(N, c)
        n1 = N - n0
        ### partition whole sample set to two classes
        spDict = {} #dictionary of sample point<---->lass
        spC0 = np.random.choice(N, n0, replace=False)
        spC1 = np.delete(np.arange(N), spC0, None)

        for s0 in spC0: 
            spDict[s0] = 0
        for s1 in spC1:
            spDict[s1] = 1

        #print("spDict: ", spDict)
        #print("C0: ",n0,spC0,"\n","C1: ",n1,spC1)
        
        ### assign bin number to each sample point
        bins = [0]*16
        for tmpI in np.arange(b):
            bins[tmpI] = []
        for spIdx in np.arange(N):
            if spDict[spIdx] == 0:
                binDistri = np.random.multinomial(1, p_i, size=1) 
                #print("binDistri: ", binDistri) 
                binAssign = np.argwhere(binDistri == 1) 
                #print("binAssign: ", binAssign) 
                bins[binAssign[0,1]].append(spIdx)
            elif spDict[spIdx] == 1:
                binDistri = np.random.multinomial(1, q_i, size=1)
                #print("binDistri: ", binDistri) 
                binAssign = np.argwhere(binDistri == 1)
                #print("binAssign: ", binAssign)
                bins[binAssign[0,1]].append(spIdx)
        #print("bins: ",bins)
        ### transform bins type from list to array
        # binsArr = np.array(bins)
        # for tmpI in np.arange(b):
        #     binsArr[tmpI] = np.array(binsArr[tmpI])
        #print(binsArr)

        ## Step B: update hyperparameters ##
        cPost = 0.5
        # count U_jy
        UClass0 = np.zeros([1,16],dtype=int)
        UClass1 = np.zeros([1,16],dtype=int)
        for tmpI in np.arange(b):
            if len(bins[tmpI]) > 0:
                for tmpEle in bins[tmpI]:
                    if spDict[tmpEle] == 0:
                        UClass0[0][tmpI] += 1
                    else: 
                        UClass1[0][tmpI] += 1
        #print("UClass0: ", UClass0)
        #print("UClass1: ", UClass1)

        # hyperparameters for p,q
        alphaPostC0 = np.add(alphaC0[caseNum], UClass0)
        alphaPostC1 = np.add(alphaC1[caseNum], UClass1)

        #print("alPostC0: ", alphaPostC0)
        #print("alPostC1: ", alphaPostC1)

        ## Step C: design classifier (majority voting) ##
        binClass = np.array([-1]*16)
        for tmpI in np.arange(b):
            if UClass1[0][tmpI] > UClass0[0][tmpI]:
                binClass[tmpI] = 1
            elif UClass1[0][tmpI] < UClass0[0][tmpI]:
                binClass[tmpI] = 0
            else:
                pass
        #print("binClass: ", binClass)

        ## Step D: error outputs ##
        # true error
        TE = 0.
        for tmpI in np.arange(b):
            if binClass[tmpI] == 1:
                TE += c*p_i[tmpI]
            elif binClass[tmpI] == 0:
                TE += (1-c)*q_i[tmpI]
            else:
                TE += c*p_i[tmpI] + (1-c)*q_i[tmpI]
        #print("TE: ", TE)
        #print("BE: ", BE)

        # Bayes MMSE
        BMMSE = 0.
        sumAlphaC0 = np.sum(alphaC0[caseNum])
        sumAlphaC1 = np.sum(alphaC1[caseNum])
        for tmpI in np.arange(b):
            if binClass[tmpI] == 1:
                BMMSE += cPost*alphaPostC0[0][tmpI]/(n0+sumAlphaC0)
            elif binClass[tmpI] == 0:
                BMMSE += (1-cPost)*alphaPostC1[0][tmpI]/(n1+sumAlphaC1)
            else:
                BMMSE += cPost*alphaPostC0[0][tmpI]/(n0+sumAlphaC0) + (1-cPost)*alphaPostC1[0][tmpI]/(n1+sumAlphaC1)
        #print("BMMSE: ", BMMSE)
        RMS_BMMSE += np.power(BMMSE-TE, 2)

        #resubstitution error
        RE = 0.
        RESum = 0.
        for tmpI in np.arange(b):
            if len(bins[tmpI]) > 0:
                for tmpEle in bins[tmpI]:
                    if binClass[tmpI] > -1:
                        RESum += np.absolute(binClass[tmpI]-spDict[tmpEle])
                    else:
                        RESum += 1
        RE = RESum/N
        #print("RE: ", RE)
        RMS_RESUB += np.power(RE-TE, 2)

        #LOO error
        LOOESum = 0.
        LOOE = 0.
        for tmpI in np.arange(b):
            if len(bins[tmpI]) > 0:
                for tmpEle in bins[tmpI]:
                    #remove one element
                    numC0 = UClass0[0][tmpI]
                    numC1 = UClass1[0][tmpI]
                    if spDict[tmpEle] == 0:
                        numC0 -= 1
                    elif spDict[tmpEle] == 1:
                        numC1 -= 1
                    else:
                        pass
                    #reassign bin class
                    if numC0 > numC1:
                        newBinC = 0
                    elif numC0 < numC1:
                        newBinC = 1
                    else:
                        newBinC = -1
                    #calculate error
                    if newBinC != spDict[tmpEle]:
                        LOOESum += 1
        LOOE = LOOESum/N
        #print("LOOE: ",LOOE)
        RMS_LOO += np.power(LOOE-TE, 2)

    # calculate RMS deviation
    RMS_BMMSE = np.sqrt(RMS_BMMSE/spNum)
    RMS_RESUB = np.sqrt(RMS_RESUB/spNum)
    RMS_LOO = np.sqrt(RMS_LOO/spNum)

    RMS_LOO_ARR = np.append(RMS_LOO_ARR, RMS_LOO)
    RMS_RESUB_ARR = np.append(RMS_RESUB_ARR, RMS_RESUB)
    RMS_BMMSE_ARR = np.append(RMS_BMMSE_ARR, RMS_BMMSE)

    print("RMS LOO: ", RMS_LOO)
    print("RMS RESUB: ", RMS_RESUB)
    print("RMS BMMSE: ", RMS_BMMSE)
    print("\n")


#draw the figure
fig, ax = plt.subplots()
ax.plot(bayesErr, RMS_LOO_ARR, marker='o', markerfacecolor='none', markersize=5, label='loo')
ax.plot(bayesErr, RMS_RESUB_ARR, marker='+', label='resub/plugin')
ax.plot(bayesErr, RMS_BMMSE_ARR, label='Bayes')
yMax = np.ceil(np.max(RMS_BMMSE_ARR)*10)/10
ax.axis([0,0.5,0,yMax])
ax.set_xlabel('Bayes error')
ax.set_ylabel('RMS deviation from true error')
legend = ax.legend(loc='upper left')
for label in legend.get_texts():
    label.set_fontsize('large')

for label in legend.get_lines():
    label.set_linewidth(1.5)
#plt.show()
fig.savefig("case " + str(caseNum) + ".png")